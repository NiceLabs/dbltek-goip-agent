#ifndef _SEND_HTTP
#define _SEND_HTTP

int send_http(char* addr, char* name, char* num, char* content);

#endif
