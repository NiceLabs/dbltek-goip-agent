#ifndef _SEND_MAIL
#define _SEND_MAIL

int send_mail(char* dest_mail, char* title, char* content);

#endif
