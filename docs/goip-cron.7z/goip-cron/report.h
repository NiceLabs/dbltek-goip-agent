#ifndef _REPORT_H
#define _REPORT_H
int report_check(int check_soon);
int check_email_forward_sms(int id, char* name, char* recvnum, char* recvmsg);
int report_init();

#endif
