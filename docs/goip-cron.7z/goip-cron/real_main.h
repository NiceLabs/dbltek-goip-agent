#ifndef REAL_MAIN_H
#define REAL_MAIN_H
int real_main(int argc, char** argv);
#endif
