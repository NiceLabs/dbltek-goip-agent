<?php
Header("Location: admin/index.php"); 
?>
