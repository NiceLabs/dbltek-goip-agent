GRANT all ON autocfg_en.* TO autocfg@localhost IDENTIFIED BY 'autocfg';
