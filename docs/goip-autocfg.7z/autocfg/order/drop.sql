DROP DATABASE IF EXISTS `autocfg_en`;
DROP DATABASE IF EXISTS `autocfg`;
create database autocfg_en;
