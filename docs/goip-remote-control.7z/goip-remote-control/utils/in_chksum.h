#ifndef _IN_CHKSUM_H_
#define _IN_CHKSUM_H_

unsigned short in_chksum(unsigned short* addr, int len);

#endif
